package ua.nure.entity.value;

public enum UserRole {
    ADMIN, USER
}
