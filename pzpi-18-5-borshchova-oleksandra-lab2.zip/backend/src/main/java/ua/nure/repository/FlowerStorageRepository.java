package ua.nure.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ua.nure.dto.FlowerStorageInfoDto;
import ua.nure.entity.FlowerStorage;

import java.util.Set;

@Repository
public interface FlowerStorageRepository extends CrudRepository<FlowerStorage, Long> {

}
